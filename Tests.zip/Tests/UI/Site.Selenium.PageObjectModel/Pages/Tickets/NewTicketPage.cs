﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using Site.Selenium.PageObjectModel.General.Controls.WebForms;
using Site.Selenium.PageObjectModel.General.Pages.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Site.Selenium.PageObjectModel.Pages.Tickets
{
    public class NewTicketPage : TestUIBasePageWebForms
    {
        // Private vars
        private TestUIRadioButtonList _TargetGroupSelector;

        private TextUICheckBox _CloseTicketImmediatelyCheckBox;
        private TestUIAutoCompleteTextBox _BankAutoCompleteTextBox;
        private TestUIDropDown _TicketTypeDropDown;
        private TestUIAutoCompleteTextBox _RequestorAutoCompleteTextBox;
        private TestUIDropDown _RequesterRoleDropDown;
        private TextUITextBox _RequesterPhoneTextBox;
        private TestUIDropDown _TicketChannelDropDown;
        private TestUIAutoCompleteTextBox _InitiatorAutoCompleteTextBox;

        private TestUIRaboDropdownTreeView _TicketSubjectTreeView;
        private TextUITextBox _TicketTitleTextBox;
        private TextUITextBox _TicketDescriptionTextBox;
        private TestUIDropDown _PriorityDropDown;

        private TestUIButton _SaveButton;
        private TextUILink _ContinueLink;


        /// <summary>
        /// Doelgroup/TargetGroup
        /// </summary>
        public TestUIRadioButtonList TargetGroupSelector
        {
            get
            {
                if (_TargetGroupSelector == null)
                {
                    string mainTableId = "mainContent_TargetGroupSelector_TargetGroupList";
                    _TargetGroupSelector = new TestUIRadioButtonList(_WebDriver, mainTableId);
                }

                return _TargetGroupSelector;
            }
        }


        /// <summary>
        /// Direct sluiten
        /// </summary>
        public TextUICheckBox CloseTicketImmediatelyCheckBox
        {
            get
            {
                if (_CloseTicketImmediatelyCheckBox == null)
                {
                    string mainInputId = "mainContent_tabContainer_InstructionPanel_TicketEditor_CloseTicketImmediately";
                    _CloseTicketImmediatelyCheckBox = new TextUICheckBox(_WebDriver, mainInputId);
                }

                return _CloseTicketImmediatelyCheckBox;
            }
        }

        /// <summary>
        /// Bank
        /// </summary>
        public TestUIAutoCompleteTextBox BankAutoCompleteTextBox
        {
            get
            {
                if (_BankAutoCompleteTextBox == null)
                {
                    string mainTextBoxId = "mainContent_tabContainer_InstructionPanel_TicketEditor_BankAutoCompleteRac_tbAutoComplete";
                    _BankAutoCompleteTextBox = new TestUIAutoCompleteTextBox(_WebDriver, mainTextBoxId);
                }

                return _BankAutoCompleteTextBox;
            }
        }

        /// <summary>
        /// Type
        /// </summary>
        public TestUIDropDown TicketTypeDropDown
        {
            get
            {
                if (_TicketTypeDropDown == null)
                {
                    string mainSelectId = "mainContent_tabContainer_InstructionPanel_TicketEditor_TicketTypeDropDown";
                    _TicketTypeDropDown = new TestUIDropDown(_WebDriver, mainSelectId);
                }

                return _TicketTypeDropDown;
            }
        }

        /// <summary>
        /// Aanvrager
        /// </summary>
        public TestUIAutoCompleteTextBox RequestorAutoCompleteTextBox
        {
            get
            {
                if (_RequestorAutoCompleteTextBox == null)
                {
                    string mainTextBoxId = "mainContent_tabContainer_InstructionPanel_TicketEditor_RequesterAutoCompleteRac_tbAutoComplete";
                    _RequestorAutoCompleteTextBox = new TestUIAutoCompleteTextBox(_WebDriver, mainTextBoxId);
                }

                return _RequestorAutoCompleteTextBox;
            }
        }

        /// <summary>
        /// Aanvrager rol
        /// </summary>
        public TestUIDropDown RequesterRoleDropDown
        {
            get
            {
                if (_RequesterRoleDropDown == null)
                {
                    string mainSelectId = "mainContent_tabContainer_InstructionPanel_TicketEditor_RequesterRoleDropDown";
                    _RequesterRoleDropDown = new TestUIDropDown(_WebDriver, mainSelectId);
                }

                return _RequesterRoleDropDown;
            }
        }

        /// <summary>
        /// Aanvrager telefoonnr.
        /// </summary>
        public TextUITextBox RequesterPhoneTextBox
        {
            get
            {
                if (_RequesterPhoneTextBox == null)
                {
                    string mainInputId = "mainContent_tabContainer_InstructionPanel_TicketEditor_RequesterPhoneTextBox";
                    _RequesterPhoneTextBox = new TextUITextBox(_WebDriver, mainInputId);
                }

                return _RequesterPhoneTextBox;
            }
        }

        /// <summary>
        /// Kanaal
        /// </summary>
        public TestUIDropDown TicketChannelDropDown
        {
            get
            {
                if (_TicketChannelDropDown == null)
                {
                    string mainSelectId = "mainContent_tabContainer_InstructionPanel_TicketEditor_TicketChannelDropDown";
                    _TicketChannelDropDown = new TestUIDropDown(_WebDriver, mainSelectId);
                }

                return _TicketChannelDropDown;
            }
        }

        /// <summary>
        /// Geregistreerd door
        /// </summary>
        public TestUIAutoCompleteTextBox InitiatorAutoCompleteTextBox
        {
            get
            {
                if (_InitiatorAutoCompleteTextBox == null)
                {
                    string mainTextBoxId = "mainContent_tabContainer_InstructionPanel_TicketEditor_InitiatorAutoCompleteRac_tbAutoComplete";
                    _InitiatorAutoCompleteTextBox = new TestUIAutoCompleteTextBox(_WebDriver, mainTextBoxId);
                }

                return _InitiatorAutoCompleteTextBox;
            }
        }

        /// <summary>
        /// Onderwerp
        /// </summary>
        public TestUIRaboDropdownTreeView TicketSubjectTreeView
        {
            get
            {
                if (_TicketSubjectTreeView == null)
                {
                    string mainSpanId = "mainContent_tabContainer_InstructionPanel_TicketEditor_TicketSubjectInput";
                    _TicketSubjectTreeView = new TestUIRaboDropdownTreeView(_WebDriver, mainSpanId);
                }

                return _TicketSubjectTreeView;
            }
        }

        /// <summary>
        /// Melding titel
        /// </summary>
        public TextUITextBox TicketTitleTextBox
        {
            get
            {
                if (_TicketTitleTextBox == null)
                {
                    string mainInputId = "mainContent_tabContainer_InstructionPanel_TicketEditor_TicketTitleTextBox";
                    _TicketTitleTextBox = new TextUITextBox(_WebDriver, mainInputId);
                }

                return _TicketTitleTextBox;
            }
        }

        /// <summary>
        /// Melding
        /// </summary>
        public TextUITextBox TicketDescriptionTextBox
        {
            get
            {
                if (_TicketDescriptionTextBox == null)
                {
                    string mainInputId = "mainContent_tabContainer_InstructionPanel_TicketEditor_TicketDescriptionTextBox";
                    _TicketDescriptionTextBox = new TextUITextBox(_WebDriver, mainInputId);
                }

                return _TicketDescriptionTextBox;
            }
        }

        /// <summary>
        /// Prioriteit
        /// </summary>
        public TestUIDropDown PriorityDropDown
        {
            get
            {
                if (_PriorityDropDown == null)
                {
                    string mainSelectId = "mainContent_tabContainer_InstructionPanel_TicketEditor_PriorityDropDown";
                    _PriorityDropDown = new TestUIDropDown(_WebDriver, mainSelectId);
                }

                return _PriorityDropDown;
            }
        }


        public TestUIButton SaveButton
        {
            get
            {
                if (_SaveButton == null)
                {
                    string mainSelectId = "mainContent_SaveButton";
                    _SaveButton = new TestUIButton(_WebDriver, mainSelectId);
                }

                return _SaveButton;
            }
        }


        public bool IsSuccessPopupVisible()
        {
            try
            {
                return IsElementVisible("mainContent_TicketCreatedPopup");
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public TextUILink ContinueLink
        {
            get
            {
                if (_ContinueLink == null)
                {
                    string mainLinkId = "mainContent_TicketCreatedPopup_ContinueButton";
                    _ContinueLink = new TextUILink(_WebDriver, mainLinkId);
                }

                return _ContinueLink;
            }
        }


        // "~/Pages/NewTicket.aspx?TargetGroupId=3"
        /// <summary>
        /// Constructor
        /// </summary>
        public NewTicketPage(IWebDriver webDriver) : base(webDriver, "~/Pages/NewTicket.aspx")
        {
        }

        public sealed override void InitElements()
        {
            PageFactory.InitElements(this, new RetryingElementLocator(_WebDriver, TimeSpan.FromSeconds(5)));
        }

    }
}
