﻿using OpenQA.Selenium;
using Site.Selenium.PageObjectModel.General.Pages;


namespace Site.Selenium.PageObjectModel.General.Helpers
{
    /// <summary>
    /// Login via the Portal
    /// </summary>
    public class LoginHelper
    {
        // UserRole constants
        //
        // Aoc
        public static readonly string AOC_User = "AocFlowUser";
        public static readonly string AOC_Beheerder = "AOC_Beheerder";
        public static readonly string AOC_ServiceDesk = "AOC_ServiceDesk";
        public static readonly string AocFlowVerificationUser = "AocFlowVerificationUser";
        public static readonly string AOC_2deLijn = "AOC_2deLijn";
        public static readonly string AOC_FunctioneelBeheerder = "AOC_FunctioneelBeheerder";
        public static readonly string AOC_LokaleBank = "3764.AlkmaarBedrijfsManagement";
        public static readonly string AOC_readOnly = "AOC_ReadOnly";

        private static string _password = "12345678";


        public static bool Login(IWebDriver webDriver, string username, string password)
        {
            PortalLoginPage loginPage = new PortalLoginPage(webDriver);
            loginPage.Goto();

            return loginPage.Login(username, password);
        }

        public static bool LoginAsAOC_ServiceDesk(IWebDriver webDriver)
        {
            return Login(webDriver, AOC_ServiceDesk, _password);
        }

    }

}
