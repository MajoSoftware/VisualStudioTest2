﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using OpenQA.Selenium;
using SeleniumFixture.xUnit;
using SeleniumFixture.xUnit.Impl;


namespace Site.Selenium.PageObjectModel.General.Fixtures
{
    public class RaboFirefoxRemoteDriverAttribute : RemoteDriverAttribute
    {
        public RaboFirefoxRemoteDriverAttribute() : base(RemoteWebDriverCapability.FireFox)
        {
        }

        public override void ReturnDriver(MethodInfo testMethod, IWebDriver driver)
        {
            this.ReturnDriver(testMethod, driver as RaboFirefoxRemoteDriver);
        }

        public override IEnumerable<IWebDriver> GetDrivers(MethodInfo testMethod)
        {
            if (Debugger.IsAttached)
                yield break;

            yield return GetOrCreateWebDriver(testMethod, () => CreateRemoteWebDriver(testMethod, Capability, Hub));
        }

        public RaboFirefoxRemoteDriver CreateRemoteWebDriver(MethodInfo testMethod, RemoteWebDriverCapability capability, string hub)
        {
            var capabilities = RaboDesiredCapabilities.Firefox();

            if (string.IsNullOrEmpty(hub))
            {
                var attr = ReflectionHelper.GetAttribute<RemoteWebDriverHubAddressAttribute>(testMethod);

                if (attr != null)
                {
                    hub = attr.Hub;
                }
            }

            return CreateWebDriverInstance(testMethod, hub, capabilities);
        }

        public static RaboFirefoxRemoteDriver CreateWebDriverInstance(MethodInfo testMethod, string hub, ICapabilities capabilities)
        {
            var driver = string.IsNullOrEmpty(hub) ? new RaboFirefoxRemoteDriver(capabilities) : new RaboFirefoxRemoteDriver(new Uri(hub), capabilities, TimeSpan.FromMinutes(60));

            InitializeDriver(testMethod, driver);

            return driver;
        }
    }
}
