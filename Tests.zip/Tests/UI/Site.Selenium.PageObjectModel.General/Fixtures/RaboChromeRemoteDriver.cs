﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;


namespace Site.Selenium.PageObjectModel.General.Fixtures
{
    public class RaboChromeRemoteDriver : RemoteWebDriver
    {
        public RaboChromeRemoteDriver(ICapabilities desiredCapabilities) : base(desiredCapabilities)
        {
        }

        public RaboChromeRemoteDriver(Uri remoteAddress, ICapabilities desiredCapabilities) : base(remoteAddress, desiredCapabilities)
        {
        }

        public RaboChromeRemoteDriver(Uri remoteAddress, ICapabilities desiredCapabilities, TimeSpan commandTimeout) : base(remoteAddress, desiredCapabilities, commandTimeout)
        {
        }

        public RaboChromeRemoteDriver(ICommandExecutor commandExecutor, ICapabilities desiredCapabilities) : base(commandExecutor, desiredCapabilities)
        {
        }
    }
}
