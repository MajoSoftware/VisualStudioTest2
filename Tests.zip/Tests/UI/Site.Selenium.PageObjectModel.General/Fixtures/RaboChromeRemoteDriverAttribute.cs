﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using SeleniumFixture.xUnit;
using SeleniumFixture.xUnit.Impl;


namespace Site.Selenium.PageObjectModel.General.Fixtures
{
    public class RaboChromeRemoteDriverAttribute : RemoteDriverAttribute
    {
        public RaboChromeRemoteDriverAttribute() : base(RemoteWebDriverCapability.Chrome)
        {
        }

        public override void ReturnDriver(MethodInfo testMethod, IWebDriver driver)
        {
            this.ReturnDriver(testMethod, driver as RaboChromeRemoteDriver);
        }

        public override IEnumerable<IWebDriver> GetDrivers(MethodInfo testMethod)
        {
            if (Debugger.IsAttached)
                yield break;

            yield return GetOrCreateWebDriver(testMethod, () => CreateRemoteWebDriver(testMethod, Capability, Hub));
        }

        public RaboChromeRemoteDriver CreateRemoteWebDriver(MethodInfo testMethod, RemoteWebDriverCapability capability, string hub)
        {
            var capabilities = RaboDesiredCapabilities.Chrome();

            if (string.IsNullOrEmpty(hub))
            {
                var attr = ReflectionHelper.GetAttribute<RemoteWebDriverHubAddressAttribute>(testMethod);

                if (attr != null)
                {
                    hub = attr.Hub;
                }
            }

            return CreateWebDriverInstance(testMethod, hub, capabilities);
        }

        public static RaboChromeRemoteDriver CreateWebDriverInstance(MethodInfo testMethod, string hub, ICapabilities capabilities)
        {
            var driver = string.IsNullOrEmpty(hub) ? new RaboChromeRemoteDriver(capabilities) : new RaboChromeRemoteDriver(new Uri(hub), capabilities, TimeSpan.FromMinutes(60));

            InitializeDriver(testMethod, driver);

            return driver;
        }
    }
}
