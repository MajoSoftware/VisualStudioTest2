﻿using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;


namespace Site.Selenium.PageObjectModel.General.Fixtures
{
    public static class RaboDesiredCapabilities
    {
        /// <summary>
        /// Get the capabilities needed for remote Firefox webdriver
        /// </summary>
        /// <returns></returns>
        public static DesiredCapabilities Firefox()
        {
            var capabilities = DesiredCapabilities.Firefox();
            var profile = RaboFirefoxProfile.Desktop();

            capabilities.SetCapability("UnexpectedAlertBehavior", "accept");
            capabilities.SetCapability(FirefoxDriver.ProfileCapabilityName, profile.ToBase64String());

            return capabilities;
        }

        /// <summary>
        /// Get the capabilities needed for remote Chrome webdriver
        /// </summary>
        /// <returns></returns>
        public static DesiredCapabilities Chrome()
        {
            var opt = new ChromeOptions();

            //important for passing through windows authentication
            opt.AddArgument("--auth-server-whitelist=\"http://crisportal.rabodev.com,http://gfportal.rabodev.com,https://crisportal.rabodev.com,https://gfportal.rabodev.com,http://localhost\"");
            opt.AddArgument("--start-maximized");
            opt.AddArgument("--no-sandbox"); //important when the selenium service runs in the background.

            var capabilities = opt.ToCapabilities() as DesiredCapabilities;

            capabilities?.SetCapability("IntroduceInstabilityByIgnoringProtectedModeSettings", true);

            return capabilities;
        }
    }
}
