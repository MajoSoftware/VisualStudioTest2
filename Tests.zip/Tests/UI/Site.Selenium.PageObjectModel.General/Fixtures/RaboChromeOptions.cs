﻿using System.Reflection;
using OpenQA.Selenium.Chrome;
using SeleniumFixture.xUnit;


namespace Site.Selenium.PageObjectModel.General.Fixtures
{
    public class RaboChromeOptions : ChromeOptionsAttribute
    {
        public bool EnableMobileEmulation { get; set; } = false;
        public string MobileDeviceName { get; set; } = "Samsung Galaxy S4";

        public override ChromeOptions ProvideOptions(MethodInfo testMethod)
        {
            ChromeOptions option = new ChromeOptions();

            if (EnableMobileEmulation)
                option.EnableMobileEmulation(MobileDeviceName);

            option.AddArgument("disable-extensions");
            option.AddArgument("--start-maximized");

            return option;
        }
    }
}
