﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using OpenQA.Selenium;
using SeleniumFixture.xUnit;


namespace Site.Selenium.PageObjectModel.General.Fixtures
{
    public class RaboChromeDriverAttribute : ChromeDriverAttribute
    {
        public override IEnumerable<IWebDriver> GetDrivers(MethodInfo testMethod)
        {
            return base.GetDrivers(testMethod);
        }
    }

    public class RaboChromeDriverOnlyWhenDebuggingAttribute : RaboChromeDriverAttribute
    {
        public override IEnumerable<IWebDriver> GetDrivers(MethodInfo testMethod)
        {
            if (Debugger.IsAttached)
                return base.GetDrivers(testMethod);

            return Enumerable.Empty<IWebDriver>();
        }
    }
}
