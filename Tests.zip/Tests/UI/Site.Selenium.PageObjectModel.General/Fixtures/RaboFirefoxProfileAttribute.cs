﻿using System.Reflection;
using OpenQA.Selenium.Firefox;
using SeleniumFixture.xUnit;


namespace Site.Selenium.PageObjectModel.General.Fixtures
{
    public class RaboFirefoxProfileAttribute : FirefoxProfileAttribute
    {
        public override FirefoxProfile CreateProfile(MethodInfo methodInfo)
        {
            return RaboFirefoxProfile.Desktop();
        }
    }
}
