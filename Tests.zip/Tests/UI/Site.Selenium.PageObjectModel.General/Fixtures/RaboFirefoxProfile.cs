﻿using OpenQA.Selenium.Firefox;


namespace Site.Selenium.PageObjectModel.General.Fixtures
{
    public static class RaboFirefoxProfile
    {
        public static FirefoxProfile Desktop()
        {
            var profile = new FirefoxProfile();

            profile.SetPreference("network.automatic-ntlm-auth.trusted-uris", "http://crisportal.rabodev.com, http://gfportal.rabodev.com,https://crisportal.rabodev.com, https://gfportal.rabodev.com,http://localhost");

            return profile;
        }
    }
}
