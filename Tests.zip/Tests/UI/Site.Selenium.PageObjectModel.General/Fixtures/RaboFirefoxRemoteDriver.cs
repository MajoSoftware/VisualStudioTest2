﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;


namespace Site.Selenium.PageObjectModel.General.Fixtures
{
    /// <summary>
    /// Needed to support shared remote webdrivers because of wrong cache implementation in SeleniumFixture
    /// see bug: https://github.com/ipjohnson/SeleniumFixture/issues/7
    /// </summary>
    public class RaboFirefoxRemoteDriver : RemoteWebDriver
    {
        public RaboFirefoxRemoteDriver(ICapabilities desiredCapabilities) : base(desiredCapabilities)
        {
        }

        public RaboFirefoxRemoteDriver(Uri remoteAddress, ICapabilities desiredCapabilities) : base(remoteAddress, desiredCapabilities)
        {
        }

        public RaboFirefoxRemoteDriver(Uri remoteAddress, ICapabilities desiredCapabilities, TimeSpan commandTimeout) : base(remoteAddress, desiredCapabilities, commandTimeout)
        {
        }

        public RaboFirefoxRemoteDriver(ICommandExecutor commandExecutor, ICapabilities desiredCapabilities) : base(commandExecutor, desiredCapabilities)
        {
        }
    }
}
