﻿using System;
using System.Reflection;
using OpenQA.Selenium;
using SeleniumFixture.xUnit;


namespace Site.Selenium.PageObjectModel.General.Fixtures
{
    public class RaboWebDriverInitializationAttribute : Attribute, IWebDriverInitializationAttribute
    {
        public virtual void Initialize(MethodInfo method, IWebDriver driver)
        {
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(20));
            driver.Manage().Timeouts().SetPageLoadTimeout(TimeSpan.FromSeconds(30));
        }
    }
}
