﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Site.Selenium.PageObjectModel.General.Extensions
{
    public static class WebDriverExtensions
    {
        /// <summary>
        /// Find an Element, and wait for the find till a max. amount of time
        /// Can result in element if found. If not found, then NoSuchElementException or TimeoutException.
        /// </summary>
        public static IWebElement FindElementWait(this IWebDriver driver, By by, int timeoutInSeconds)
        {
            if (timeoutInSeconds > 0)
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                return wait.Until(drv => drv.FindElement(by));
            }
            return driver.FindElement(by);
        }

        /// <summary>
        /// Find Elements, and wait for the find till a max. amount of time
        /// Can result in element if found. If not found, then NoSuchElementException or TimeoutException.
        /// </summary>
        public static ReadOnlyCollection<IWebElement> FindElementsWait(this IWebDriver driver, By by, int timeoutInSeconds)
        {
            if (timeoutInSeconds > 0)
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                return wait.Until(drv => drv.FindElements(by));
            }
            return driver.FindElements(by);
        }

    }

}
