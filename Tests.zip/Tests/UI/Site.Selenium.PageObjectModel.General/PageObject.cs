﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Site.Selenium.PageObjectModel.General
{
    /// <summary>
    /// Abstract Object base class (used for 'Page Object' Design Pattern).
    /// Can be inherited to create a higher level object abstraction than html (e.g. objects like Header, Grid, Menu, Page etc.) which contains 
    /// the actual underlying (Selenium)html elements. These objects abstract away the actual html-elements / details.
    /// The Objects to be created are completely arbitrary composed by a developer.
    /// </summary>
    public abstract class PageObject
    {
        protected IWebDriver _WebDriver;
        private readonly Func<IWebDriver, object> _waitForPageLoadImpl;

        protected PageObject(IWebDriver webDriver, Func<IWebDriver, object> waitForPageLoadImpl = null)
        {
            if (webDriver == null) throw new ArgumentNullException(nameof(webDriver));
            _WebDriver = webDriver;

            // Trick to know via jquery when a page is loaded
            _waitForPageLoadImpl = waitForPageLoadImpl ?? (driver =>
                ((IJavaScriptExecutor)driver).ExecuteScript(
                    "return (document.readyState === \"complete\") && ((window.jQuery || { active : 0 }).active == 0);"));
        }

        /// <summary>
        /// Makes the browser wait until the page is loaded.
        /// </summary>
        protected virtual void WaitForPageLoad()
        {
            var wait = new WebDriverWait(_WebDriver, TimeSpan.FromSeconds(30));

            try
            {
                wait.Until(_waitForPageLoadImpl);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }
        public void Wait(TimeSpan timeSpan)
        {
            System.Threading.Thread.Sleep(timeSpan);
        }
    }
}
