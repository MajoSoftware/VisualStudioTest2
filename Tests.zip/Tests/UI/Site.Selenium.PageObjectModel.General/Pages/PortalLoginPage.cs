﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Site.Selenium.PageObjectModel.General.Pages.Shared;
using System;


namespace Site.Selenium.PageObjectModel.General.Pages
{
    public class PortalLoginPage : TestUIBasePageWebForms
    {
        [FindsBy(How = How.Id, Using = "ctl00_ContentPlaceHolder1_ucLogin_txtLoginName")]
        private IWebElement _LoginNameTextBox;

        [FindsBy(How = How.Id, Using = "ctl00_ContentPlaceHolder1_ucLogin_txtPassword")]
        private IWebElement _PasswordTextBox;

        [FindsBy(How = How.Id, Using = "ctl00_ContentPlaceHolder1_ucLogin_lbtLogin")]
        private IWebElement _LoginLink;


        public string LoginName
        {
            get { return _LoginNameTextBox.GetAttribute("value"); }
            set { _LoginNameTextBox.SendKeys(value); }
        }

        public string Password
        {
            get { return _PasswordTextBox.GetAttribute("value"); }
            set { _PasswordTextBox.SendKeys(value); }
        }

        public IWebElement LoginLink
        {
            get { return _LoginLink; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public PortalLoginPage(IWebDriver webDriver) : base(webDriver, "Login.aspx")
        {
        }

        public sealed override void InitElements()
        {
            PageFactory.InitElements(this, new RetryingElementLocator(_WebDriver, TimeSpan.FromSeconds(5)));
        }

        public bool Login(string loginName, string password)
        {
            LoginName = loginName;
            Password = password;

            LoginLink.Click();

            // Not on login page anymore, but on home page
            bool result = !IsAtUrl();
            return result;
        }

    }

}
