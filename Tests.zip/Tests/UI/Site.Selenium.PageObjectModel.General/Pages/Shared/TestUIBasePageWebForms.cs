﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Site.Selenium.PageObjectModel.General.Extensions;


namespace Site.Selenium.PageObjectModel.General.Pages.Shared
{
    /// <summary>
    /// Inherit from this base class for WebForms application, and add all actual html elements in that page.
    /// Or divide those further into multiple Page Objects and put the elements in there, and let the page contain those Page Objects.
    /// </summary>
    public abstract class TestUIBasePageWebForms : TestUIBasePage
    {
        /// <summary>
        /// Constructor 1
        /// </summary>
        protected TestUIBasePageWebForms(IWebDriver webDriver, string relativeUrl) : base(webDriver, relativeUrl)
        {
        }

        /// <summary>
        /// Constructor 2
        /// </summary>
        protected TestUIBasePageWebForms(IWebDriver webDriver, string baseUrl, string relativeUrl) : base(webDriver, baseUrl, relativeUrl)
        {
        }

    }

}
