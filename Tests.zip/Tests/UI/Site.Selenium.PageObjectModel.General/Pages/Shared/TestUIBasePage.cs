﻿using System;
using System.Configuration;
using System.Linq;
using System.Web.Mvc;
using System.Web.Routing;
using OpenQA.Selenium;
using Site.Selenium.PageObjectModel.General.Extensions;


namespace Site.Selenium.PageObjectModel.General.Pages.Shared
{
    /// <summary>
    /// Base Page for all pages in web application.
    /// General class for both MVC as WebForms. Do not inherit from this class, but from 'TestUIBasePageMvc' or 'TestUIBasePageWebForms'
    /// </summary>
    public abstract class TestUIBasePage : PageObject
    {
        private string _baseUrl;
        private string _relativeUrl;
        private string _absoluteUrl;
        private string _portalBaseUrl;


        public string BaseUrl
        {
            get
            {
                // Get the url from config file
                if (string.IsNullOrEmpty(_baseUrl))
                {
                    if (ConfigurationManager.AppSettings["Selenium:AppBaseUrl"] == null)
                        throw new Exception("Setting 'Selenium:AppBaseUrl' is missing in the config file.");

                    _baseUrl = ConfigurationManager.AppSettings["Selenium:AppBaseUrl"];
                }

                return _baseUrl;
            }
            set
            {
                _baseUrl = value;
            }
        }


        public string PortalBaseUrl
        {
            get
            {
                if (string.IsNullOrEmpty(_portalBaseUrl))
                {
                    _portalBaseUrl = BaseUrl;

                    if (_portalBaseUrl.EndsWith("/"))
                        _portalBaseUrl = BaseUrl.Remove(_portalBaseUrl.Length - 1);

                    int indexLastSlash = _portalBaseUrl.LastIndexOf('/');
                    if (indexLastSlash != -1)
                    {
                        _portalBaseUrl = _portalBaseUrl.Remove(indexLastSlash);
                    }
                }

                return _portalBaseUrl;
            }
            set
            {
                _portalBaseUrl = value;
            }
        }



        public string RelativeUrl { get { return _relativeUrl; } }

        public string AbsoluteUrl
        {
            get
            {
                if (string.IsNullOrEmpty(_absoluteUrl))
                {
                    if (_relativeUrl.Contains("Login.aspx"))
                        _absoluteUrl = PortalBaseUrl + "/" + "Login.aspx";
                    else
                        _absoluteUrl = CreateAbsoluteUrl();
                }

                return _absoluteUrl;
            }
        }

        /// <summary>
        /// Constructor 1
        /// </summary>
        protected TestUIBasePage(IWebDriver webDriver, string relativeUrl) : base(webDriver)
        {
            if (relativeUrl == null) throw new ArgumentNullException(nameof(relativeUrl));
            _relativeUrl = relativeUrl;
        }

        /// <summary>
        /// Constructor 2
        /// </summary>
        protected TestUIBasePage(IWebDriver webDriver, string baseUrl, string relativeUrl) : base(webDriver)
        {
            if (baseUrl == null) throw new ArgumentNullException(nameof(baseUrl));
            if (relativeUrl == null) throw new ArgumentNullException(nameof(relativeUrl));

            BaseUrl = baseUrl;
            _relativeUrl = relativeUrl;
        }

        /// <summary>
        /// Finds all needed elements on the page. Can also be used after a page postback.
        /// </summary>
        public abstract void InitElements();


        private string CreateAbsoluteUrl()
        {
            var tmpBaseUrl = BaseUrl;

            // Remove possible endslash at end
            if (tmpBaseUrl.EndsWith("/"))
                tmpBaseUrl = tmpBaseUrl.Substring(0, tmpBaseUrl.Length - 1);

            var tmpRelativeUrl = RelativeUrl;

            // Remove possible endslash at begin
            if (tmpRelativeUrl.StartsWith("~/"))
                tmpRelativeUrl = tmpRelativeUrl.Replace("~/", "/");
            
            if (!tmpRelativeUrl.StartsWith("/"))
                tmpRelativeUrl = $"/{tmpRelativeUrl}";

            string result = $"{tmpBaseUrl}{tmpRelativeUrl}";
            return result;
        }

        /// <summary>
        /// Navigates to the current page Url
        /// </summary>
        public virtual void Goto()
        {
            try
            {
                _WebDriver.Navigate().GoToUrl(AbsoluteUrl);

                WaitForPageLoad();

                InitElements();

                if (!IsAtUrl(ignoreQueryString: true) && !HasError())
                {
                    RaiseGotoError(null);
                }
            }
            catch (Exception e)
            {
                RaiseGotoError(e);
            }
        }

        private void RaiseGotoError(Exception innerException)
        {
            throw new Exception(GetType().Name + " could not be loaded. Check if the page url is correct. Current page url is: " + AbsoluteUrl, innerException);
        }

        /// <summary>
        /// Let the browser go back to the previous page
        /// </summary>
        public virtual void GoBack()
        {
            try
            {
                _WebDriver.Navigate().Back();
                WaitForPageLoad();
            }
            catch (Exception e)
            {
                throw new Exception(GetType().Name + " could not be loaded. Check page url is correct." + e.Message);
            }
        }

        /// <summary>
        /// Check if current browser page is equal to the page that was navigated to
        /// </summary>
        /// <param name="ignoreQueryString"></param>
        /// <returns></returns>
        public virtual bool IsAtUrl(bool ignoreQueryString = false)
        {
            string browserUrl = _WebDriver.Url;
            string pageUrl = AbsoluteUrl;

            if (ignoreQueryString)
            {
                var browserUri = new Uri(browserUrl);
                browserUrl = browserUri.GetLeftPart(UriPartial.Path);

                var pageUri = new Uri(AbsoluteUrl);
                pageUrl = pageUri.GetLeftPart(UriPartial.Path);
            }

            bool result = browserUrl.Equals(pageUrl, StringComparison.InvariantCultureIgnoreCase);
            return result;
        }

        public virtual bool HasError()
        {
            //the selenium webdriver doesn't support HTTP status codes so we are going to hack this up
            return (_WebDriver.FindElements(By.ClassName("has-error")).Any() ||
                _WebDriver.PageSource.Contains("Server Error")); // User Friendlier Error Page || YSOD
        }

        /// <summary>
        /// Javascript Confirmation dialog
        /// </summary>
        public virtual void SetConfirmDialogResult(bool accept)
        {
            try
            {
                IAlert alert = _WebDriver.SwitchTo().Alert();
                if (accept)
                {
                    alert.Accept();
                }                
                else
                {
                    alert.Dismiss();
                }
            }
            catch (NoAlertPresentException ex)
            {
            }
        }

        public bool IsElementVisible(string elementId)
        {
            IWebElement element = _WebDriver.FindElementWait(By.Id(elementId), 30);
            if (element != null)
            {
                return element.Displayed;
            }

            return false;
        }
   
    }

}
