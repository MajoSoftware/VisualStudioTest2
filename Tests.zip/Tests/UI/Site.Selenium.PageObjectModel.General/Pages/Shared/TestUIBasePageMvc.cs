﻿using OpenQA.Selenium;


namespace Site.Selenium.PageObjectModel.General.Pages.Shared
{
    /// <summary>
    /// Inherit from this base class for MVC Application, and add all actual html elements in that page.
    /// Or divide those further into multiple Page Objects and put the elements in there, and let the page contain those Page Objects.
    /// </summary>
    public abstract class TestUIBasePageMvc : TestUIBasePage
    {
        /// <summary>
        /// Constructor 1
        /// </summary>
        protected TestUIBasePageMvc(IWebDriver webDriver, string relativeUrl) : base(webDriver, relativeUrl)
        {
        }

        /// <summary>
        /// Constructor 2
        /// </summary>
        protected TestUIBasePageMvc(IWebDriver webDriver, string baseUrl, string relativeUrl) : base(webDriver, baseUrl, relativeUrl)
        {
        }

    }
}
