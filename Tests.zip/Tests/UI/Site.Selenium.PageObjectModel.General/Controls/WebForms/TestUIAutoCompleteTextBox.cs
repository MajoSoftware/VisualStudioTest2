﻿using OpenQA.Selenium;
using Rabo.Selenium.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using Site.Selenium.PageObjectModel.General.Extensions;


namespace Site.Selenium.PageObjectModel.General.Controls.WebForms
{
    public class TestUIAutoCompleteTextBox : TestUIBaseControl
    {
        private string _HiddenValueElementId;


        // Constructor 1
        public TestUIAutoCompleteTextBox(IWebDriver webDriver, string mainId) : base(webDriver, mainId)
        {
            Init();
        }

        private void Init()
        {
            _HiddenValueElementId = _MainId.Replace("_tbAutoComplete", "_hfAutoComplete");
        }

        /// <summary>
        /// HiddenValueElement
        /// </summary>
        protected TestUIHiddenField HiddenValueElement
        {
            get { return new TestUIHiddenField(_WebDriver, _HiddenValueElementId); }
        }

        public string GetSelectedText()
        {
            return MainElement.GetAttribute("value");
        }

        public string GetSelectedValue()
        {
            return HiddenValueElement.GetSelectedValue();
        }

        public void SetSelectedValue(string value)
        {
            HiddenValueElement.SetSelectedValue(value);
        }

        /// <summary>
        /// SetSelectedtext
        /// </summary>
        /// <param name="searchText">Text to serahc on. E.g.: 'ma' gives items '1127 - Maas Waal' and '3764 - Alkmaar e.o.'.</param>
        /// <param name="pickRandomItem">Pick first item match? Or else choose random item</param>
        public void SetSelectedText(string searchText, bool pickRandomItem)
        {
            string unOrderListId = _MainId.Replace("_tbAutoComplete", "_aceAutoComplete_completionListElem");

            if (string.IsNullOrEmpty(searchText))
                throw new Exception(string.Format("Empty searchText for AutoCompleteTextBox with Id '{0}'.", unOrderListId));

            MainElement.Clear(); // Needed because there can be some content in the TextBox!
            MainElement.SendKeys(searchText); // Fill TextBox with content
            //_MainElement.SendKeys(Keys.Enter);

            string itemsIds = string.Format("#{0} li", unOrderListId);
            List<IWebElement> listItems = _WebDriver.FindElementsWait(By.CssSelector(itemsIds), _TimeOutSeconds).ToList();

            if (listItems.Count > 0)
            {
                if (!pickRandomItem)
                {
                    listItems[0].Click();
                }
                else
                {
                    int randomItemIndex = new Random().Next(0, listItems.Count);
                    listItems[randomItemIndex].Click();
                }
            }
            else
            {
                throw new Exception(string.Format("No items found in AutoCompleteTextBox with Id '{0}'.", unOrderListId));
            }
        }

    }
}
