﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using Site.Selenium.PageObjectModel.General.Extensions;


namespace Site.Selenium.PageObjectModel.General.Controls.WebForms
{
    public class TestUIButton : TestUIBaseControl
    {
        // Constructor 1
        public TestUIButton(IWebDriver webDriver, string mainId) : base(webDriver, mainId)
        {
        }

        public void Click()
        {
            MainElement.Click();
        }

    }

}
