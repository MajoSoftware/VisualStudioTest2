﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Site.Selenium.PageObjectModel.General.Extensions;


namespace Site.Selenium.PageObjectModel.General.Controls.WebForms
{
    public class TextUICheckBox : TestUIBaseControl
    {
        // Constructor 1
        public TextUICheckBox(IWebDriver webDriver, string mainId) : base(webDriver, mainId)
        {
        }

        public bool GetSelectedValue()
        {
            return MainElement.Selected;
        }

        public void SetSelectedValue(bool value)
        {
            if (value)
            {
                if (!MainElement.Selected)
                    MainElement.Click();
            }
            else
            {
                if (MainElement.Selected)
                    MainElement.Click();
            }
        }

    }
}
