﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Site.Selenium.PageObjectModel.General.Controls.WebForms
{
    /// <summary>
    /// General ListItem. E.g. for dropdown or radioButtonList.
    /// </summary>
    public class TestUIListItem
    {
        public TestUIListItem(IWebElement element, string value = null, string text = null)
        {
            Element = element;
            Value = value;
            Text = text;
        }

        public IWebElement Element { get; set; }
        public string Value { get; set; }
        public string Text { get; set; }
    }

    /// <summary>
    /// General ListItem, inclusing Selected property. E.g. for dropdown or radioButtonList.
    /// </summary>
    public class TestUISelListItem : TestUIListItem
    {
        public TestUISelListItem(IWebElement element, string value = null, string text = null, bool selected = false) : base(element, value, text)
        {
            Element = element;
            Value = value;
            Text = text;
            Selected = selected;
        }

        public bool Selected { get; set; }
    }

}
