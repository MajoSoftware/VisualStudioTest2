﻿using OpenQA.Selenium;
using Site.Selenium.PageObjectModel.General.Extensions;


namespace Site.Selenium.PageObjectModel.General.Controls.WebForms
{
    /// <summary>
    /// Base class for all Test Controls
    /// </summary>
    public class TestUIBaseControl
    {
        protected IWebDriver _WebDriver;

        // E.g.: "mainContent_tabContainer_InstructionPanel_TicketEditor_TicketSubjectInput"
        // AutoCompleteTextBox:             TextBox Id (input)
        // TextUITextBox:                   TextBox Id (input)
        // TestUIRaboDropdownTreeView:      Span Id
        // TestUIHiddenField:               HiddenField Id (input)
        // TestUIDropDown:                  DropDown Id (select)
        protected string _MainId;

        protected int _TimeOutSeconds;

        // Constructor 1
        public TestUIBaseControl(IWebDriver webDriver, string mainId) : base()
        {
            _WebDriver = webDriver;
            _MainId = mainId;
            _TimeOutSeconds = 30;
        }

        public string MainId
        {
            get { return _MainId; }
        }

        /// <summary>
        /// MainElement
        /// E.g. a TextBox or a Span
        /// </summary>
        protected IWebElement MainElement
        {
            // Always get the element again/fresh, because after a Postback the element has no valid attachment anymore
            get { return _WebDriver.FindElementWait(By.Id(_MainId), _TimeOutSeconds); }
        }

    }
}
