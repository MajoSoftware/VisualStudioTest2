﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Site.Selenium.PageObjectModel.General.Extensions;

namespace Site.Selenium.PageObjectModel.General.Controls.WebForms
{
    public class TestUIRadioButtonList : TestUIBaseControl
    {
        // Constructor 1
        public TestUIRadioButtonList(IWebDriver webDriver, string mainId) : base(webDriver, mainId)
        {
        }


        public string GetSelectedText()
        {
            TestUISelListItem selItem = Items.FirstOrDefault(i => i.Selected == true);
            if (selItem != null)
                return selItem.Text;
            else
                throw new Exception(string.Format("No selected item(text) element found for control with Id: '{0}'.", _MainId));
        }

        public string GetSelectedValue()
        {
            TestUISelListItem selItem = Items.FirstOrDefault(i => i.Selected == true);
            if (selItem != null)
                return selItem.Value;
            else
                throw new Exception(string.Format("No selected item(value) element found for control with Id: '{0}'.", _MainId));
        }


        protected List<TestUISelListItem> Items
        {
            get
            {
                List<TestUISelListItem> resultList = new List<TestUISelListItem>();

                // Find all items with a Id starting with same Id as the radioButtons list
                string radioButtonsClass = string.Format("input[id^={0}]", _MainId);
                List<IWebElement> radioButtonElements = _WebDriver.FindElementsWait(By.CssSelector(radioButtonsClass), _TimeOutSeconds).ToList();

                // Find all corresponding labels for each radiobutton
                string itemsLabels = string.Format("#{0} label", _MainId);
                List<IWebElement> itemLabels = _WebDriver.FindElementsWait(By.CssSelector(itemsLabels), _TimeOutSeconds).ToList();

                // RadioButton elems
                foreach (IWebElement inputElem in radioButtonElements)
                {
                    string itemValue = inputElem.GetAttribute("value");
                    TestUISelListItem item = new TestUISelListItem(inputElem, itemValue, null);
                    item.Selected = inputElem.Selected;
                    resultList.Add(item);
                }

                // Labels for radiobutton items
                foreach (IWebElement labelElem in itemLabels)
                {
                    string labelFor = labelElem.GetAttribute("for");
                    string strIndex = labelFor.Replace(_MainId + "_", "");

                    int labelIndex = 0;
                    int.TryParse(strIndex, out labelIndex);

                    if (labelIndex < resultList.Count)
                    {
                        resultList[labelIndex].Text = labelElem.GetAttribute("innerHTML");
                    }
                }

                return resultList;
            }
        }


        public void SetSelectedValue(string value)
        {
            TestUISelListItem selItem = Items.FirstOrDefault(i => i.Value == value);
            if (selItem != null)
                selItem.Element.Click();
            else
                throw new Exception(string.Format("No item element found value text {0} for control with Id: '{1}'.", value, _MainId));
        }

        public void SetSelectedText(string text)
        {
            TestUISelListItem selItem = Items.FirstOrDefault(i => i.Text == text);
            if (selItem != null)
                selItem.Element.Click();
            else
                throw new Exception(string.Format("No item element found with text {0} for control with Id: '{1}'.", text, _MainId));
        }

        public void SetSelectedRandomItem()
        {
            if (Items.Count > 0)
            {
                int randomItemIndex = new Random().Next(0, Items.Count);
                Items[randomItemIndex].Element.Click();
            }
            else
                throw new Exception(string.Format("No item elements found for control with Id: '{0}'.", _MainId));
        }

    }

}
