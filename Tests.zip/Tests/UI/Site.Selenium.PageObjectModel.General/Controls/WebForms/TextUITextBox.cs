﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Site.Selenium.PageObjectModel.General.Extensions;


namespace Site.Selenium.PageObjectModel.General.Controls.WebForms
{
    public class TextUITextBox : TestUIBaseControl
    {
        // Constructor 1
        public TextUITextBox(IWebDriver webDriver, string mainId) : base(webDriver, mainId)
        {
        }

        public string GetSelectedText()
        {
            return MainElement.GetAttribute("innerHTML");
        }

        public string GetSelectedValue()
        {
            return MainElement.GetAttribute("value");
        }

        public void SetSelectedValue(string value)
        {
            MainElement.Clear();
            MainElement.SendKeys(value);
        }

    }
}
