﻿using OpenQA.Selenium;
using Rabo.Selenium.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using Site.Selenium.PageObjectModel.General.Extensions;


namespace Site.Selenium.PageObjectModel.General.Controls.WebForms
{
    /// <summary>
    /// TestUIRaboDropdownTreeView
    /// Namespace pc4 Rabo.CRG.CRIS.BDS.Portal.Controls
    /// (Please be aware of the fact that there are more implementations/versions of this control with different namespaces!)
    /// </summary>
    public class TestUIRaboDropdownTreeView : TestUIBaseControl
    {
        private bool _ItemsExpanded;


        // Constructor 1
        public TestUIRaboDropdownTreeView(IWebDriver webDriver, string mainId) : base(webDriver, mainId)
        {
            _ItemsExpanded = false;
        }


        protected IWebElement ValueSpan
        {
            get
            {
                string valueSpanId = string.Format("{0}_lblResult", _MainId);
                IWebElement valueSpan = _WebDriver.FindElementWait(By.Id(valueSpanId), _TimeOutSeconds);
                return valueSpan;
            }
        }

        protected IWebElement OpenTreeButton
        {
            get
            {
                string openTreeButtonId = string.Format("{0}_lblOpen", _MainId);
                IWebElement openTreeButton = _WebDriver.FindElement(By.Id(openTreeButtonId), 30);
                return openTreeButton;
            }
        }

        protected List<TestUIListItem> Items
        {
            get
            {
                List<TestUIListItem> resultList = new List<TestUIListItem>();

                // ".mainContent_tabContainer_InstructionPanel_TicketEditor_TicketSubjectInput_tv_0.NodeStyle.mainContent_tabContainer_InstructionPanel_TicketEditor_TicketSubjectInput_tv_1"
                string optionLinkElemsClass = string.Format(".{0}_tv_0.NodeStyle.{1}_tv_1", _MainId, _MainId);
                List<IWebElement> optionLinkElements = _WebDriver.FindElementsWait(By.CssSelector(optionLinkElemsClass), _TimeOutSeconds).ToList();
                foreach (IWebElement optionElem in optionLinkElements)
                {
                    TestUIListItem item = new TestUIListItem(optionElem);
                    FillValueAndTextFromHref(optionElem, item);
                    resultList.Add(item);
                }

                return resultList;
            }
        }



        public string GetSelectedText()
        {
            string selectedText = null;           
            if (ValueSpan != null)
            {
                selectedText = ValueSpan.GetAttribute("innerHTML");
            }
            else
                throw new Exception(string.Format("No selected item(text) found for control with Id: '{0}'.", _MainId));

            return selectedText;
        }

        public string GetSelectedValue()
        {
            string value = null;

            string selectedText = GetSelectedText();
            TestUIListItem selectedItem = Items.FirstOrDefault(i => i.Text == selectedText);
            if (selectedItem != null)
                value = selectedItem.Value;
            else
                throw new Exception(string.Format("No selected item(value) found for control with Id: '{0}'.", _MainId));

            return value;
        }

        public void SetSelectedValue(string value)
        {
            // ! Tree needs to be opened / items have to be visible to be selectable
            OpenTreeButtonClick();

            // Search for item with this value, and click on it
            TestUIListItem item = Items.FirstOrDefault(i => i.Value == value);
            if (item != null)
            {
                item.Element.Click();
            }
            else
                throw new Exception(string.Format("No selected item(value) found to set for control with Id: '{0}'.", _MainId));
        }

        public void SetSelectedText(string text)
        {
            // ! Tree needs to be opened / items have to be visible to be selectable
            OpenTreeButtonClick();

            // Search for item with this value, and click on it
            TestUIListItem item = Items.FirstOrDefault(i => i.Text == text);
            if (item != null)
            {
                item.Element.Click();
            }
            else
                throw new Exception(string.Format("No selected item(text) found to set for control with Id: '{0}'.", _MainId));
        }

        public void SetRandomItem()
        {
            // ! Tree needs to be opened / items have to be visible to be selectable
            OpenTreeButtonClick();

            if (Items.Count > 0)
            {
                // Pick first visible element (because it is a treecontrol, you have to expand sub-items to be visible.
                // If invisible, then also not clickable -> Error
                TestUIListItem item = Items.FirstOrDefault(i => (i.Element.Displayed == true));
                if (item != null)
                {
                    item.Element.Click();
                }
                else
                {
                    throw new Exception(string.Format("No visible item element found for control with Id: '{0}'.", _MainId));
                }
            }
        }

        private void OpenTreeButtonClick()
        {
            if (!_ItemsExpanded)
            {
                OpenTreeButton.Click();
                _ItemsExpanded = !_ItemsExpanded;
            }
        }


        // href="javascript:__doPostBack('ctl00$mainContent$tabContainer$InstructionPanel$TicketEditor$TicketSubjectInput$tv','s8\\19')">Item1
        // href="javascript:__doPostBack('ctl00$mainContent$tabContainer$InstructionPanel$TicketEditor$TicketSubjectInput$tv','s20')"
        private void FillValueAndTextFromHref(IWebElement elem, TestUIListItem item)
        {
            string href = elem.GetAttribute("href");
            int jsPostbackIndex = href.IndexOf("javascript:__doPostBack('");
            if (jsPostbackIndex != -1)
            {
                href = href.Remove(jsPostbackIndex, 25);
                int sepIndex = href.IndexOf("','");
                if (sepIndex != -1)
                {
                    href = href.Remove(0, (sepIndex + 3));
                    int lastQuoteIndex = href.IndexOf("'");
                    if (lastQuoteIndex != -1)
                    {
                        href = href.Remove(lastQuoteIndex);
                        string[] valuesArr = href.Split(new string[] { "\\" }, StringSplitOptions.None);
                        string itemValue = valuesArr[valuesArr.Length - 1];
                        itemValue = itemValue.Replace("s", "");
                        item.Value = itemValue;
                    }
                }
            }

            item.Text = elem.GetAttribute("innerHTML");
        }

    }

}
