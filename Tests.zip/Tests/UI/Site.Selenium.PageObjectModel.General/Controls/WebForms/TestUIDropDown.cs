﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Site.Selenium.PageObjectModel.General.Extensions;


namespace Site.Selenium.PageObjectModel.General.Controls.WebForms
{
    public class TestUIDropDown : TestUIBaseControl
    {
        // Constructor 1
        public TestUIDropDown(IWebDriver webDriver, string mainId) : base(webDriver, mainId)
        {
        }

        protected SelectElement SelectElement
        {
            get { return new SelectElement(MainElement); }
        }

        public string GetSelectedText()
        {
            if (SelectElement.SelectedOption != null)
            {
                return SelectElement.SelectedOption.Text;
            }

            return null;
        }

        public string GetSelectedValue()
        {
            return MainElement.GetAttribute("value");
        }

        public void SetSelectedValue(string value)
        {
            SelectElement.SelectByValue(value);
        }

        public void SetSelectedText(string text)
        {
            SelectElement.SelectByText(text);
        }

        public void SetSelectedRandomItem()
        {
            if (SelectElement.Options.Count > 0)
            {
                int randomItemIndex = 0;
                if (SelectElement.Options[0].Text == "-Selecteer-")
                {
                    if (SelectElement.Options.Count > 1)
                        randomItemIndex = new Random().Next(1, SelectElement.Options.Count);
                }
                else
                    randomItemIndex = new Random().Next(0, SelectElement.Options.Count);

                SelectElement.SelectByIndex(randomItemIndex);
            }
            else
            {
                throw new Exception(string.Format("No dropdown items found for control with id {0}.", _MainId));
            }
                       
        }

    }
}
