﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Site.Selenium.PageObjectModel.General.Extensions;


namespace Site.Selenium.PageObjectModel.General.Controls.WebForms
{
    public class TestUIHiddenField : TestUIBaseControl
    {
        // Constructor 1
        public TestUIHiddenField(IWebDriver webDriver, string mainId) : base(webDriver, mainId)
        {
        }

        public string GetSelectedValue()
        {
            string script = string.Format("return document.getElementById('{0}').getAttribute('value');", _MainId);
            string value = ((IJavaScriptExecutor)_WebDriver).ExecuteScript(script).ToString();

            return value;
        }

        public void SetSelectedValue(string value)
        {
            string script = string.Format("document.getElementById('{0}').value='{1}';", _MainId, value);
            ((IJavaScriptExecutor)_WebDriver).ExecuteScript(script);
        }

    }
}
