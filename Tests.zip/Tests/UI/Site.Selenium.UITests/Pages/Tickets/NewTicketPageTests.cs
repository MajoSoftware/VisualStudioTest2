﻿//using FluentAssertions;
using FluentAssertions;
using OpenQA.Selenium;
using SeleniumFixture;
using SeleniumFixture.xUnit;
using Site.Selenium.PageObjectModel.General.Fixtures;
using Site.Selenium.PageObjectModel.General.Helpers;
using Site.Selenium.PageObjectModel.Pages;
using Site.Selenium.PageObjectModel.Pages.Tickets;
using System;
//using Site.Selenium.PageObjectModel.Pages.Desktop.General;
//using Site.Selenium.UITests.Fixtures;
using Xunit;


namespace Site.Selenium.UITests.Pages.Tickets
{
    // InternetExplorerOptions
    // InternetExplorerDriver

    [Trait("Category", "DesktopBrowserTests")]                                              // Test description
    [RaboChromeRemoteDriver(Shared = true)]                                                 // Remote server (grid) Chrome
    //[RaboFirefoxRemoteDriver(Shared = true)]                                              // Remote server (grid) Firefox
    [RemoteWebDriverHubAddress(Hub = "http://sdeuc4110088:4444/wd/hub")]                    // Remote server (grid) hub to execute test for buildserver
    [RaboChromeDriverOnlyWhenDebugging(Shared = true)]                                      // Chrome local debug
    [RaboChromeOptions]                                                                     // Chrome settings
    //[RaboFirefoxDriverOnlyWhenDebugging(Shared = true)]                                   // Firefox local debug
    //[RaboFirefoxProfile]                                                                  // Firefox settings
    [RaboWebDriverInitialization]                                                           // For all drivers
    public class NewTicketPageTests
    {
        [SeleniumTheory]
        public void Test_InsertNewServicedeskLocalBankTicket_Success(Fixture fixture)
        {


            // Arrange
            bool loginResult = LoginHelper.LoginAsAOC_ServiceDesk(fixture.Driver);
            Assert.True(loginResult);

            // Act
            NewTicketPage newTicketPage = new NewTicketPage(fixture.Driver);
            newTicketPage.Goto();

            // Check if browser at specified page Url
            bool isAtUrl = newTicketPage.IsAtUrl(true);

            // Select Targetgroup 'Lokale bank'
            newTicketPage.TargetGroupSelector.SetSelectedText("Lokale bank");

            // Set ticket fields
            newTicketPage.CloseTicketImmediatelyCheckBox.SetSelectedValue(false);
            newTicketPage.BankAutoCompleteTextBox.SetSelectedText("ma", false); // "1127 - Maas Waal"
            newTicketPage.TicketTypeDropDown.SetSelectedValue("2");
            newTicketPage.RequestorAutoCompleteTextBox.SetSelectedText("de", true);
            newTicketPage.RequesterRoleDropDown.SetSelectedRandomItem();
            newTicketPage.RequesterPhoneTextBox.SetSelectedValue("12345");
            newTicketPage.TicketChannelDropDown.SetSelectedText("Telefonisch");
            newTicketPage.InitiatorAutoCompleteTextBox.SetSelectedText("se", true);
            newTicketPage.TicketSubjectTreeView.SetRandomItem();
            newTicketPage.TicketTitleTextBox.SetSelectedValue("probleem...");
            newTicketPage.TicketDescriptionTextBox.SetSelectedValue("probleem omschrijving...");
            newTicketPage.PriorityDropDown.SetSelectedText("Normaal");

            // Save selection of requesterRole before saving ticket
            string requesterRole = newTicketPage.RequesterRoleDropDown.GetSelectedText();

            // Save ticket
            newTicketPage.SaveButton.Click();

            newTicketPage.SetConfirmDialogResult(true);

            // Check if success saved dialog is present. If so, you can see/click link 'Doorgaan'
            // Also expected behaviour when error from Aoc BusinessLogic 'Functional mailbox address could not be determined for role Operationeel Beheerder (id 1) and bank Alkmaar e.o. (id 8)'
            bool successSavedPopupVisible = newTicketPage.IsSuccessPopupVisible();

            bool testResult = successSavedPopupVisible || ((!successSavedPopupVisible) && (requesterRole == "Operationeel Beheerder"));
            Assert.True(testResult);
        }


    }
}
