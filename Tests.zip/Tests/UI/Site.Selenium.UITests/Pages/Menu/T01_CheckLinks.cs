﻿//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using Rabo.Selenium;
//using Rabo.Selenium.Extensions;
//using WebsiteTests.Pages;

//namespace Site.Selenium.UITests.Pages.Menu
//{
//    [TestClass]
//    public class T01_CheckLinks
//    {
//        [TestMethod]
//        [Ignore]
//        public void T01_CheckMenuItemsAOC_Beheerder()
//        {
//            //using (var driver = new Wrapper(new SeleniumConfig() { saveScreenShots = true }).GetDriver())
//            using (var driver = new Wrapper().GetDriver())
//            {
//                LoginPage.GoToLoginPage(driver).LoginAsAOC_Beheerder();

//                var bar = MenuBar.GetMenuBar(driver);
//                //Sjabloon
//                bar.InstructionTemplateMenuPart.GoToNewInstructionTemplate();
//                AssertExtensions.IsNotErrorOccuredInApplication(driver);
//                bar.InstructionTemplateMenuPart.GoToInstructionTemplateOverview();
//                AssertExtensions.IsNotErrorOccuredInApplication(driver);
//                //Opdracht
//                bar.InstructionMenuPart.GoToInstructionOverview();
//                AssertExtensions.IsNotErrorOccuredInApplication(driver);
//                bar.InstructionMenuPart.GoToMakeAvailableOverview();
//                AssertExtensions.IsNotErrorOccuredInApplication(driver);
//                bar.InstructionMenuPart.GoToNewInstruction();
//                AssertExtensions.IsNotErrorOccuredInApplication(driver);
//                bar.InstructionMenuPart.GoToNewVerificationInstruction();
//                AssertExtensions.IsNotErrorOccuredInApplication(driver);
//                //Reports
//                //No test for report because tableau is not available in dev
//                //Assert.AreEqual(1, 2);// trigger failure for bis test

//            }
//        }
//    }
//}

