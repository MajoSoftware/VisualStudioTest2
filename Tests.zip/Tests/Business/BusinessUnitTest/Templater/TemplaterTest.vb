﻿Imports System.Text
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports Rabo.AocFlow.Business

<TestClass()>
Public Class TemplaterTest

    <TestMethod()>
    Public Sub FillTemplate_FillsTemplate()
        Dim expectedResult As String = "Hoi ik ben een geweldige template"

        Dim templater As ITemplater = New Templater()

        Dim template As String = "Hoi ik ben een ##TemplateNaam## template"
        Dim params As New Dictionary(Of String, String)()
        params.Add("TemplateNaam", "geweldige")

        Dim result = templater.FillTemplate(template, params)

        Assert.AreEqual(expectedResult, result)
    End Sub

    <TestMethod()>
    <ExpectedException(GetType(ArgumentException))>
    Public Sub FillTemplate_ThrowsExceptionOnMissingParameter()
        Dim templater As ITemplater = New Templater()

        Dim template As String = "Hoi ik ben een ##TemplateNaam## template"
        Dim params As New Dictionary(Of String, String)()

        templater.FillTemplate(template, params)
    End Sub

End Class