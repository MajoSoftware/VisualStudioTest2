﻿Imports Microsoft.VisualStudio.TestTools.UnitTesting

Imports Rabo.AocFlow.Business
Imports Moq
Imports Rabo.AocFlow.Data
Imports Rabo.AocFlow
Imports Rabo.AocFlow.Model
Imports Rabo.AocFlow.Util


Namespace Rabo.AocFlow.Business.Tests

    <TestClass()>
    Public Class RequestServiceTest

        Friend Class RequestTestObject
            Friend Property RequestServiceMock As RequestService

            Friend Property CommonServiceMock As Mock(Of ICommonService)

            Friend Property RepoMock As Mock(Of IRequestRepository)
        End Class

        <TestMethod()>
        Public Sub RequestService_VerifyChangeRequestStatus()

            Dim requestTestObject = CreateRequestServiceWithRepositoryMock()

            Dim request As New Request() With {
                .StatusId = RequestStatusEnum.None
            }

            Assert.IsTrue(request.StatusId = RequestStatusEnum.None)

            requestTestObject.RequestServiceMock.ChangeStatus(request, Model.ActionEnum.MakeRequest)
            Assert.IsTrue(request.StatusId = RequestStatusEnum.Creating)

            requestTestObject.RequestServiceMock.ChangeStatus(request, Model.ActionEnum.SendRequest)
            Assert.IsTrue(request.StatusId = RequestStatusEnum.Requested)

            requestTestObject.RequestServiceMock.ChangeStatus(request, Model.ActionEnum.SendReply)
            Assert.IsTrue(request.StatusId = RequestStatusEnum.Answered)

            requestTestObject.RequestServiceMock.ChangeStatus(request, Model.ActionEnum.CompletingRequest)
            Assert.IsTrue(request.StatusId = RequestStatusEnum.Handled)

        End Sub

        <TestMethod()>
        Public Sub RequestService_VerifySendReminderRequestsHasRunSuccesfull()
            Dim requestTestObject = CreateRequestServiceWithRepositoryMock()
            Dim requestRepo = requestTestObject.RepoMock
            Dim commonServ = requestTestObject.CommonServiceMock

            Dim reminderDate = DateTime.Now

            Dim listOfRequestReminders = New List(Of RequestReminderOverview)()

            requestRepo.Setup(Function(x) x.GetRequestReminders()).Returns(listOfRequestReminders)

            Dim success = True
            Try
                requestTestObject.RequestServiceMock.SendReminderRequests()
            Catch ex As Exception
                success = False
            End Try
            Assert.IsTrue(success)

            commonServ.Verify(Sub(x) x.UpdateApplicationSetting(It.IsAny(Of Integer), It.IsAny(Of String)), Times.Once)
            commonServ.Verify(Sub(x) x.UpdateApplicationSetting(Setting.ReminderTaskRunDate, reminderDate.ToString()), Times.Once)
        End Sub

        Private Shared Function CreateRequestServiceWithRepositoryMock() As RequestTestObject
            Dim requestRepoMock As New Mock(Of IRequestRepository)()
            Dim requestRepo = requestRepoMock.Object
            Dim commonServiceMock As New Mock(Of ICommonService)()

            Dim portalSettings = New Settings()
            Dim mailer = New Mailer(portalSettings)
            Dim mailComposer = New MailComposer(New CommonRepository(), New RequestRepository(New CommonRepository, New InstructionRepository), New ticketRepository(), New AddressBook(New CommonRepository(), New Logger()), New Settings, New Templater)

            Dim requestService As New RequestService(requestRepo, mailer, mailComposer, commonServiceMock.Object())

            Dim requestTestObject = New RequestTestObject()
            requestTestObject.RequestServiceMock = requestService
            requestTestObject.RepoMock = requestRepoMock
            requestTestObject.CommonServiceMock = commonServiceMock

            Return requestTestObject

        End Function

    End Class
End Namespace