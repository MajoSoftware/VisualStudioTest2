﻿Imports Rabo.AocFlow.Business
Imports Moq
Imports Rabo.AocFlow.Data
Imports Rabo.AocFlow
Imports Rabo.AocFlow.Model
Imports Rabo.AocFlow.Util
Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass()>
Public Class InstructionServiceTest
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling")>
    <TestMethod()>
    <Ignore()>
    Public Sub InstructionService_StartingInstructionWithIntervalLeadsToCreationOfNextInstruction()
        Dim startDate As New DateTime(2014, 6, 2)
        Dim expectedStartDate As New DateTime(2014, 7, 1)
        Dim expectedTitle As String = "This instruction title will be used for the next instruction"

        Dim userMock As New Mock(Of IUser)()
        userMock.SetupGet(Function(x) x.Id).Returns(1)
        Dim user = userMock.Object

        Dim repoMock As New Mock(Of IInstructionRepository)()
        repoMock.Setup(Function(x) x.BankIsPresentInTemplate(It.IsAny(Of Integer), It.IsAny(Of Integer))).Returns(Function() True)
        repoMock.Setup(Function(x) x.InstructionConcurrencyCheck(It.IsAny(Of Instruction))).Returns(Function() ConcurrencyCheckEnum.Ok)
        Dim repo = repoMock.Object

        Dim templateRepoMock As New Mock(Of IInstructionTemplateRepository)()
        Dim templateRepo = templateRepoMock.Object
        Dim commonRepoMock As New Mock(Of ICommonRepository)()
        Dim dateManager As New DateManager()
        Dim instructionManager As New InstructionManager(repo, dateManager, templateRepo, commonRepoMock.Object)

        Dim mailer As New Mock(Of IMailer)()
        Dim mailComposer As New Mock(Of IMailComposer)()

        Dim service As New InstructionService(repo, templateRepo, instructionManager, mailer.Object, mailComposer.Object, user, commonRepoMock.Object)

        Dim instruction As New Model.Instruction() With {
            .BankId = 1,
            .Description = "Long instruction text goes here",
            .EndDate = startDate.AddDays(1),
            .InitiatorRoleId = Model.RoleEnum.Administrator,
            .InitiatorUserId = 1,
            .OwnerId = Nothing,
            .PriorityId = Model.InstructionPriorityEnum.Medium,
            .ProcessTypeId = 1,
            .InstructionTemplate = New Model.InstructionTemplate() With {
                .IntervalId = Model.IntervalEnum.Month,
                .IntervalSize = 1,
                .HandlingTime = 1,
                .Workday = 1,
                .StatusId = InstructionTemplateStatusEnum.Active,
                .Title = expectedTitle
            },
            .startDate = startDate,
            .StatusId = Model.InstructionStatusEnum.NotStarted,
            .StatusInfo = "Much progress, so wow!",
            .TeamId = 1,
            .Title = expectedTitle
        }

        service.ChangeStatusAndUpdateInstruction(instruction, Model.ActionEnum.Start, user.Id)
        repoMock.Verify(Sub(x) x.Insert(It.Is(Of Model.Instruction)(Function(i) i.Title = expectedTitle AndAlso i.StartDate.Date = expectedStartDate)), Times.Once())
    End Sub
End Class