﻿Imports Rabo.AocFlow.Model.Download
Imports Rabo.AocFlow.Data
Imports Rabo.AocFlow.Business
Imports Moq
Imports System.IO.Compression
Imports System.IO
Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass()>
Public Class DownloadServiceTest
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times")>
    <TestMethod()>
    Public Sub DownloadService_DownloadMessagesAttachmentsAllUniqueFiles()
        Dim requestAttachments = CreateRequestAttachments()
        Dim notificationAttachments = CreateNotificationAttachments()

        Dim repoMock As New Mock(Of IDownloadRepository)
        repoMock.Setup(Function(x) x.GetInstructionRequestAttachments(It.IsAny(Of Integer))).Returns(Function() requestAttachments)
        repoMock.Setup(Function(x) x.GetInstructionNotificationAttachments(It.IsAny(Of Integer))).Returns(Function() notificationAttachments)
        Dim service As New DownloadService(repoMock.Object)

        Dim zipBytes = service.DownloadMessageAttachmentsAsZip(0)
        Using zipStream As New MemoryStream(zipBytes),
            archive As New ZipArchive(zipStream)

            Assert.AreEqual(requestAttachments.Count + notificationAttachments.Count, archive.Entries.Count)
            For Each entry In archive.Entries
                Dim attachments As IEnumerable(Of MessageDownloadItem) = notificationAttachments.Union(requestAttachments)
                Dim fileIsNotNumbered = attachments.Any(Function(x) entry.FullName.EndsWith(x.FileName, StringComparison.InvariantCulture))
                Assert.IsTrue(fileIsNotNumbered, "Entry.FullName: " + entry.FullName)
            Next
        End Using
    End Sub

    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times")>
    <TestMethod()>
    Public Sub DownloadService_DownloadMessagesAttachmentsHandleDoubleFileName()
        Dim requestAttachments = CreateRequestAttachments().ToList()
        requestAttachments.Add(requestAttachments.First())
        Dim notificationAttachments = CreateNotificationAttachments().ToList()
        notificationAttachments.Add(notificationAttachments.First())

        Dim repoMock As New Mock(Of IDownloadRepository)
        repoMock.Setup(Function(x) x.GetInstructionRequestAttachments(It.IsAny(Of Integer))).Returns(Function() requestAttachments)
        repoMock.Setup(Function(x) x.GetInstructionNotificationAttachments(It.IsAny(Of Integer))).Returns(Function() notificationAttachments)
        Dim service As New DownloadService(repoMock.Object)

        Dim zipBytes = service.DownloadMessageAttachmentsAsZip(0)
        Using zipStream As New MemoryStream(zipBytes),
            archive As New ZipArchive(zipStream)

            Assert.AreEqual(requestAttachments.Count + notificationAttachments.Count, archive.Entries.Count)

            Dim uniqueQuery = From e In archive.Entries
                              Group e By e.FullName Into eg = Group
                              Where eg.Count() > 1
                              Select eg
            Assert.IsFalse(uniqueQuery.Any(), "There are files with the same filename")
        End Using
    End Sub

    Private Function CreateRequestAttachments() As IEnumerable(Of RequestDownloadItem)
        Dim attachments As New List(Of RequestDownloadItem)()

        attachments.Add(
            New RequestDownloadItem() With {
                .Contents = New Byte() {},
                .FileName = "Test.txt",
                .IsReply = True,
                .ReferenceNumber = 1,
                .Subject = "Test verzoek"
            })
        attachments.Add(
            New RequestDownloadItem() With {
                .Contents = New Byte() {},
                .FileName = "Dingetje.txt",
                .IsReply = True,
                .ReferenceNumber = 1,
                .Subject = "Test verzoek"
            })
        attachments.Add(
            New RequestDownloadItem() With {
                .Contents = New Byte() {},
                .FileName = "Dingetje.txt",
                .IsReply = True,
                .ReferenceNumber = 2,
                .Subject = "Oh ja, nog iets he"
            })

        Return attachments
    End Function

    Private Function CreateNotificationAttachments() As IEnumerable(Of MessageDownloadItem)
        Dim attachments As New List(Of MessageDownloadItem)()

        attachments.Add(
            New MessageDownloadItem() With {
                .Contents = New Byte() {},
                .FileName = "Test.txt",
                .ReferenceNumber = 1,
                .Subject = "Test verzoek"
            })
        attachments.Add(
            New MessageDownloadItem() With {
                .Contents = New Byte() {},
                .FileName = "Dingetje.txt",
                .ReferenceNumber = 1,
                .Subject = "Test verzoek"
            })
        attachments.Add(
            New MessageDownloadItem() With {
                .Contents = New Byte() {},
                .FileName = "Dingetje.txt",
                .ReferenceNumber = 2,
                .Subject = "Oh ja, nog iets he"
            })

        Return attachments
    End Function
End Class