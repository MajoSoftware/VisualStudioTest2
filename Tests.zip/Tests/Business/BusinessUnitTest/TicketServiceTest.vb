﻿Imports Rabo.AocFlow.Model.Download
Imports Rabo.AocFlow.Data
Imports Rabo.AocFlow.Business
Imports Moq
Imports System.IO.Compression
Imports System.IO
Imports Rabo.AocFlow
Imports Rabo.AocFlow.Model
Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass()>
Public Class TicketServiceTest
    Private _TicketService As TicketService
    Private Shared _logger As ILogger

    <TestInitialize>
    Public Sub TestInit()
        _TicketService = Services.CreateTicketService()
        _logger = New Logger()
    End Sub

    <TestCleanup>
    Public Sub TestCleanup()
        _TicketService = Services.CreateTicketService()

    End Sub


    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times")>
    <TestMethod()>
    Public Sub TicketService_CloseTicketsAutomatically_Success()
        _logger.LogInfo("Test TicketService_CloseTicketsAutomatically_Success started.")

        _TicketService.CloseTicketsAutomatically()

        Dim commonService As CommonService = Business.Services.CreateCommonService()
        Dim defaultClosingTerm = Convert.ToInt32(commonService.GetApplicationSetting(Setting.DefaultClosingTerm).Value) * -1  ' = ususally (-)5
        Dim closingDate = commonService.AddWorkingDays(DateTime.Today(), defaultClosingTerm, True)

        Dim ticketRepo = New TicketRepository()
        Dim ticketsToClose = ticketRepo.GetTicketsToBeClosedAutomatically(closingDate)

        Assert.AreEqual(ticketsToClose.Count(), 0)
    End Sub

    <Ignore>
    <TestMethod()>
    Public Sub Test_GetTicketLastHandlerId_Success1()
        Dim lastHandlerId As Integer? = _TicketService.GetTicketLastHandlerId(63752)
        Assert.AreEqual(lastHandlerId, 10)
    End Sub

    <Ignore>
    <TestMethod()>
    Public Sub Test_GetTicketLastHandlerId_Success2()
        Dim lastHandlerId As Integer? = _TicketService.GetTicketLastHandlerId(45)
        Assert.AreEqual(lastHandlerId, 10)
    End Sub


End Class
