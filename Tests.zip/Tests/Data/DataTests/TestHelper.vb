﻿Imports System.IO
Imports System.Reflection
Imports System.Security.AccessControl

Public NotInheritable Class TestHelper
    Private Sub New()
    End Sub

    Public Shared Function CreateWorkDirectory() As String
        Dim workingId = Convert.ToString(Guid.NewGuid())
        Dim workingDirectory = Path.Combine(Path.GetTempPath(), workingId)

        Directory.CreateDirectory(workingDirectory)

        Return workingDirectory
    End Function

    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times")>
    Public Shared Function GetResource(resourceFile As String) As Byte()
        Using resource = OpenResourceStream(resourceFile),
            BinaryReader = New BinaryReader(resource)
            Return BinaryReader.ReadBytes(CInt(resource.Length))
        End Using
    End Function

    Public Shared Sub WriteResourceToFile(resourceFile As String, destination As String)
        Using resource = OpenResourceStream(resourceFile)
            SaveStreamToFile(resource, destination)
        End Using
    End Sub

    Private Shared Function OpenResourceStream(resourceFile As String) As Stream
        Dim scopeType = GetType(TestHelper)

        Return Assembly.GetExecutingAssembly().GetManifestResourceStream(scopeType, resourceFile)
    End Function

    Private Shared Sub SaveStreamToFile(Stream As Stream, destination As String)
        Using fileStream = File.Create(destination)
            Stream.Position = 0
            Stream.CopyTo(fileStream)
        End Using
    End Sub

    Public Shared Sub AddFileSecurity(fileName As String, account As String, rights As FileSystemRights, controlType As AccessControlType)
        ' Get a FileSecurity object that represents the
        ' current security settings.
        Dim acl = File.GetAccessControl(fileName)

        ' Add the FileSystemAccessRule to the security settings.
        acl.AddAccessRule(New FileSystemAccessRule(account, rights, controlType))

        ' Set the new access settings.
        File.SetAccessControl(fileName, acl)
    End Sub
End Class