﻿Imports System.Text
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports Rabo.AocFlow.Data
Imports Rabo.AocFlow.Model
Imports Rabo.AocFlow.Model.BusinessEntities

<TestClass()> Public Class TicketRepositoryTest
    Inherits RepositoryTest
    Private _ticketRepo As ITicketRepository

    <TestMethod(), Ignore>
    Public Sub GetTicketsToBeClosedAutomatically()

        Dim closingDate = DateTime.Today.AddDays(-5)
        Dim ticketsToClose As IEnumerable(Of BlTicket) = New List(Of BlTicket)

        _ticketRepo = New TicketRepository()

        ticketsToClose = _ticketRepo.GetTicketsToBeClosedAutomatically(closingdate)
        Assert.AreEqual(2, ticketsToClose.Count())

        ticketsToClose = _ticketRepo.GetTicketsToBeClosedAutomatically(closingdate)
        Assert.AreEqual(1, ticketsToClose.Count())
    End Sub



    Private Function CreateMocks() As TicketRepositoryMocks
        Return New TicketRepositoryMocks() With {.TicketRepository = New TicketRepository()}
    End Function

    Public Class TicketRepositoryMocks
        Public Property TicketRepository As TicketRepository

    End Class
End Class