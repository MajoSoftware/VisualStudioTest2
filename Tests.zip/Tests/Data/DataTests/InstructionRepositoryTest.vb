﻿Imports System.Transactions
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports Rabo.AocFlow.Data
Imports Rabo.AocFlow.Model

<TestClass()>
Public Class InstructionRepositoryTest

    <TestMethod()>
    <Ignore>
    Public Sub GetInstructionHistory_Success()
        Dim instructionRepository = New InstructionRepository()
        Dim instructionHistoryList As IEnumerable(Of InstructionHistoryOverview)

        Using transaction As New TransactionScope(TransactionScopeOption.Required, New TransactionOptions With {.IsolationLevel = IsolationLevel.Snapshot})
            instructionHistoryList = instructionRepository.GetInstructionHistory(2274)
            transaction.Complete()
        End Using

        Assert.IsTrue(instructionHistoryList.Count > 0)
    End Sub

End Class
