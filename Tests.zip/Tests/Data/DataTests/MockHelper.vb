﻿Imports Rabo.AocFlow.Model

Public Class MockHelper

    Public Shared Function CreateTemplate(userId As Integer,
                                   processTypeId As Integer) As InstructionTemplate
        Return New InstructionTemplate() With {
            .CreatedAt = DateTime.Now,
            .CreatedById = userId,
            .Description = "Template description",
            .HandlingTime = 0,
            .IntervalId = IntervalEnum.None,
            .IntervalSize = 0,
            .PriorityId = InstructionPriorityEnum.Medium,
            .ProcessTypeId = processTypeId,
            .ReminderTerm = 0,
            .ReminderTermTypeId = InstructionTemplateReminderTermTypeEnum.None,
            .StartDate = DateTime.Now,
            .StatusId = InstructionTemplateStatusEnum.Active,
            .Title = "Template title",
            .Workday = 0
        }
    End Function

    Public Shared Function CreateInstruction(bankId As Integer,
                                      userId As Integer,
                                      templateId As Integer,
                                      processTypeId As Integer,
                                      teamId As Integer) As Instruction
        Return New Instruction() With {
            .BankId = bankId,
            .Description = "Instruction description",
            .InitiatorRoleId = RoleEnum.Administrator,
            .InitiatorUserId = userId,
            .InstructionTemplateId = templateId,
            .PriorityId = InstructionPriorityEnum.Medium,
            .ProcessTypeId = processTypeId,
            .StartDate = DateTime.Now,
            .StatusId = InstructionStatusEnum.NotStarted,
            .StatusInfo = "",
            .TeamId = teamId,
            .Title = "Instruction title"
        }
    End Function

    Public Shared Function CreateRequest(instructionId As Integer,
                                  userId As Integer) As Request
        Return New Request() With {
            .Body = "Request body",
            .InstructionId = instructionId,
            .ReferenceNumber = 1,
            .RequesterId = userId,
            .SentAt = DateTime.Now,
            .StatusId = RequestStatusEnum.Requested,
            .Subject = "Request subject",
            .ReplierRoleId = RoleEnum.BedrijfsManagement
        }
    End Function

    Public Shared Function SetDefaultReminderTerm(reminderTerm As Integer) As ApplicationSetting
        Return New ApplicationSetting() With {
            .Code = "DefaultReminderTerm",
            .Name = "Default reminder term",
            .ValueType = "Integer",
            .Value = reminderTerm,
            .Id = 1
            }
    End Function

End Class
