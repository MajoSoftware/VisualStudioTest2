﻿Imports System.Transactions
Imports Microsoft.VisualStudio.TestTools.UnitTesting

<System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1001:TypesThatOwnDisposableFieldsShouldBeDisposable")>
Public Class RepositoryTest
    Private _scope As TransactionScope

    <TestInitialize>
    Public Sub TestInitialize()
        If _scope IsNot Nothing Then Throw New InvalidOperationException("_scope may not be filled at this moment")

        _scope = New TransactionScope()
    End Sub

    <TestCleanup>
    Public Sub TestCleanup()
        If _scope IsNot Nothing Then
            _scope.Dispose()
            _scope = Nothing
        End If
    End Sub
End Class