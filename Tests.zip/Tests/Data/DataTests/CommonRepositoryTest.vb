﻿Imports Rabo.AocFlow.Data
Imports Rabo.AocFlow.Model
Imports System.Data.Entity.Infrastructure
Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass>
Public Class CommonRepositoryTest
    Inherits RepositoryTest

    <TestMethod(), Ignore>
    <ExpectedException(GetType(DbUpdateException))>
    Public Sub CommonRepository_InsertBank_FailsOnDuplicateCode()
        Using context = New AocFlowEntities()
            Dim bank = CreateBank(context)
            Dim repo As New CommonRepository()

            repo.InsertBank(bank)
            repo.InsertBank(bank) 'This one fails
        End Using
    End Sub

    <TestMethod(), Ignore>
    Public Sub CommonRepository_InsertBank_InsertsNewBank()
        Using context = New AocFlowEntities()
            Dim bank = CreateBank(context)
            Dim repo As New CommonRepository()

            Dim preExists = context.Banks.Any(Function(x) x.Code = bank.Code)
            Assert.IsFalse(preExists)

            repo.InsertBank(bank)
            Dim postExists = context.Banks.Any(Function(x) x.Code = bank.Code)
            Assert.IsTrue(postExists)
        End Using
    End Sub

    Private Function CreateBank(context As AocFlowEntities) As Bank
        Dim teamId = context.Teams.First().Id

        Dim bank As New Bank()
        bank.Alias = "alias"
        bank.Code = "code"
        bank.IsDeleted = False
        bank.Name = "name"
        bank.TeamId = teamId

        Return bank
    End Function
End Class