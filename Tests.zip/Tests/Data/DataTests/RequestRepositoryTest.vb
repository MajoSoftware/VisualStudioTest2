﻿Imports Rabo.AocFlow.Data
Imports Rabo.AocFlow.Util
Imports Rabo.AocFlow.Model
Imports System.Data.Entity.Core.Objects
Imports System.Transactions
Imports System.Data.Entity
Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass()>
Public Class RequestRepositoryTest
    Inherits RepositoryTest


    <TestMethod(), Ignore>
    Public Sub RequestRepository_CalculateReminderRequests_ShouldSendFirstReminder()
        Dim request As New Request()

        Using context = New AocFlowEntities()
            request = CreateReminderRequest(context,
                                            InstructionTemplateReminderTermTypeEnum.Custom,
                                            reminderTerm:=3,
                                            sentAt:=Date.Now.AddDays(-7))
        End Using

        Dim mocks = CreateMocks()
        Dim repository = mocks.RequestRepository
        Dim reminders = repository.CalculateReminderRequests()

        Assert.AreEqual(1, reminders.Count())

        Dim reminder = reminders.Single()

        Assert.AreEqual(request.Id, reminder.RequestId)
        Assert.AreEqual(1, reminder.ReminderTemplateToSend)


    End Sub

    <TestMethod(), Ignore>
    Public Sub RequestRepository_CalculateReminderRequests_ShouldSendSecondReminder()
        Dim request As New Request()

        Using context = New AocFlowEntities()
            request = CreateReminderRequest(context,
                                            InstructionTemplateReminderTermTypeEnum.Custom,
                                            reminderTerm:=6,
                                            sentAt:=Date.Now.AddDays(-11))

            Dim mocks = CreateMocks()
            Dim repository = mocks.RequestRepository
            Dim reminders = repository.CalculateReminderRequests()

            Assert.AreEqual(1, reminders.Count())

            Dim reminder = reminders.Single()

            Assert.AreEqual(request.Id, reminder.RequestId)
            Assert.AreEqual(1, reminder.ReminderTemplateToSend)

            reminder.SentAt = Date.Now
            repository.InsertRequestReminder(reminder)

            request.SentAt = Date.Now.AddDays(-20)
            context.SaveChanges()

            reminders = repository.CalculateReminderRequests()

            Assert.AreEqual(1, reminders.Count())
            reminder = reminders.Single()
            Assert.AreEqual(request.Id, reminder.RequestId)
            Assert.AreEqual(2, reminder.ReminderTemplateToSend)
            Assert.IsNotNull(reminder.RequestSecondReminderDate)

        End Using

    End Sub

    <TestMethod(), Ignore>
    Public Sub RequestRepository_CalculateReminderRequests_ShouldSendSecondReminderAsFirstReminder()
        Dim request As New Request()

        Using context = New AocFlowEntities()
            request = CreateReminderRequest(context,
                                            InstructionTemplateReminderTermTypeEnum.Custom,
                                            reminderTerm:=3,
                                            sentAt:=Date.Now.AddDays(-15))

            Dim mocks = CreateMocks()
            Dim repository = mocks.RequestRepository
            Dim reminders = repository.CalculateReminderRequests()

            Assert.AreEqual(1, reminders.Count())

            Dim reminder = reminders.Single()

            Assert.AreEqual(request.Id, reminder.RequestId)
            Assert.AreEqual(1, reminder.ReminderTemplateToSend)
            Assert.IsNotNull(reminder.RequestSecondReminderDate)

        End Using
    End Sub

    <TestMethod(), Ignore>
    Public Sub RequestRepository_CalculateReminderRequests_FirstReminderDoesNotGetSentMoreThanOnce()

        Dim request As New Request()

        Using context = New AocFlowEntities()
            request = CreateReminderRequest(context,
                                            InstructionTemplateReminderTermTypeEnum.Custom,
                                            reminderTerm:=6,
                                            sentAt:=Date.Now.AddDays(-11))

            Dim mocks = CreateMocks()
            Dim repository = mocks.RequestRepository
            Dim reminders = repository.CalculateReminderRequests()

            Assert.AreEqual(1, reminders.Count())

            Dim reminder = reminders.Single()

            Assert.AreEqual(request.Id, reminder.RequestId)
            Assert.AreEqual(1, reminder.ReminderTemplateToSend)

            reminder.SentAt = Date.Now
            repository.InsertRequestReminder(reminder)

            reminders = repository.CalculateReminderRequests()

            Assert.AreEqual(0, reminders.Count())

        End Using
    End Sub


    <TestMethod(), Ignore>
    Public Sub RequestRepository_CalculateReminderRequests_SecondReminderDoesNotGetSentMoreThanOnce()
        Dim request As New Request()

        Using context = New AocFlowEntities()
            request = CreateReminderRequest(context,
                                            InstructionTemplateReminderTermTypeEnum.Custom,
                                            reminderTerm:=6,
                                            sentAt:=Date.Now.AddDays(-11))

            Dim mocks = CreateMocks()
            Dim repository = mocks.RequestRepository
            Dim reminders = repository.CalculateReminderRequests()

            Assert.AreEqual(1, reminders.Count())

            Dim reminder = reminders.Single()

            Assert.AreEqual(request.Id, reminder.RequestId)
            Assert.AreEqual(1, reminder.ReminderTemplateToSend)

            reminder.SentAt = Date.Now
            repository.InsertRequestReminder(reminder)

            request.SentAt = Date.Now.AddDays(-20)
            context.SaveChanges()

            reminders = repository.CalculateReminderRequests()

            Assert.AreEqual(1, reminders.Count())
            reminder = reminders.Single()
            Assert.AreEqual(request.Id, reminder.RequestId)
            Assert.AreEqual(2, reminder.ReminderTemplateToSend)
            Assert.IsNotNull(reminder.RequestSecondReminderDate)

            reminder.SentAt = Date.Now
            repository.InsertRequestReminder(reminder)

            reminders = repository.CalculateReminderRequests()

            Assert.AreEqual(0, reminders.Count())

        End Using

    End Sub

    <TestMethod(), Ignore>
    Public Sub RequestRepository_CalculateReminderRequests_SecondReminderAsFirstReminderShouldNotGetSentMoreThanOnce()
        Dim request As New Request()

        Using context = New AocFlowEntities()
            request = CreateReminderRequest(context,
                                            InstructionTemplateReminderTermTypeEnum.Custom,
                                            reminderTerm:=3,
                                            sentAt:=Date.Now.AddDays(-15))

            Dim mocks = CreateMocks()
            Dim repository = mocks.RequestRepository
            Dim reminders = repository.CalculateReminderRequests()

            Assert.AreEqual(1, reminders.Count())

            Dim reminder = reminders.Single()

            Assert.AreEqual(request.Id, reminder.RequestId)
            Assert.AreEqual(1, reminder.ReminderTemplateToSend)
            Assert.IsNotNull(reminder.RequestSecondReminderDate)

            reminder.SentAt = Date.Now
            repository.InsertRequestReminder(reminder)

            reminders = repository.CalculateReminderRequests()

            Assert.AreEqual(0, reminders.Count())

        End Using

    End Sub


    <TestMethod(), Ignore>
    Public Sub RequestRepository_CalculateReminderRequests_ShouldSendFirstReminderAfterEditingExistingReminderTerm()

        Dim request As New Request()

        Using context = New AocFlowEntities()
            request = CreateReminderRequest(context,
                                            InstructionTemplateReminderTermTypeEnum.Custom,
                                            reminderTerm:=10,
                                            sentAt:=Date.Now.AddDays(-9))

            Dim mocks = CreateMocks()
            Dim repository = mocks.RequestRepository
            Dim reminders = repository.CalculateReminderRequests()

            Assert.IsFalse(reminders.Any)

            request.Instruction.InstructionTemplate.ReminderTerm = 5
            context.SaveChanges()

            reminders = repository.CalculateReminderRequests()

            Assert.AreEqual(1, reminders.Count())

            Dim reminder = reminders.Single()

            Assert.AreEqual(5, reminder.ReminderTerm)
            Assert.AreEqual(request.Id, reminder.RequestId)
            Assert.AreEqual(1, reminder.ReminderTemplateToSend)

        End Using

    End Sub

    <TestMethod(), Ignore>
    Public Sub RequestRepository_CalculateReminderRequests_ShouldSendNoReminder()
        Dim request As New Request()

        Using context = New AocFlowEntities()
            request = CreateReminderRequest(context,
                                            InstructionTemplateReminderTermTypeEnum.Custom,
                                            reminderTerm:=5,
                                            sentAt:=Date.Now.AddDays(-4))
        End Using

        Dim mocks = CreateMocks()
        Dim repository = mocks.RequestRepository
        Dim reminders = repository.CalculateReminderRequests()

        Assert.IsFalse(reminders.Any)

    End Sub


    <TestMethod(), Ignore>
    Public Sub RequestRepository_CalculateReminderRequests_ShouldSendFirstReminderForDefaultReminderTerm()
        Dim request As New Request()
        Dim DefaultReminderTermSetting As New ApplicationSetting()

        Using context = New AocFlowEntities()
            DefaultReminderTermSetting = SetDefaultReminderTerm(context, reminderTerm:=5)

            request = CreateReminderRequest(context,
                                            InstructionTemplateReminderTermTypeEnum.Default,
                                            reminderTerm:=10,
                                            sentAt:=Date.Now.AddDays(-8))
        End Using

        Dim mocks = CreateMocks()
        Dim repository = mocks.RequestRepository
        Dim reminders = repository.CalculateReminderRequests()

        Assert.AreEqual(1, reminders.Count())

        Dim reminder = reminders.Single()

        Assert.AreEqual(request.Id, reminder.RequestId)
        Assert.AreEqual(1, reminder.ReminderTemplateToSend)
        Assert.AreEqual("5", DefaultReminderTermSetting.Value)

    End Sub


    <TestMethod(), Ignore>
    Public Sub RequestRepository_CalculateReminderRequests_ShouldSendNoReminderForNoReminderTerm()
        Dim request As New Request()
        Dim DefaultReminderTermSetting As New ApplicationSetting()

        Using context = New AocFlowEntities()
            DefaultReminderTermSetting = SetDefaultReminderTerm(context, reminderTerm:=5)

            request = CreateReminderRequest(context,
                                            InstructionTemplateReminderTermTypeEnum.None,
                                            reminderTerm:=10,
                                            sentAt:=Date.Now.AddDays(-8))
        End Using

        Dim mocks = CreateMocks()
        Dim repository = mocks.RequestRepository
        Dim reminders = repository.CalculateReminderRequests()

        Assert.AreEqual("5", DefaultReminderTermSetting.Value)
        Assert.AreEqual(0, reminders.Count())
    End Sub

    <TestMethod(), Ignore>
    Public Sub RequestRepository_GetRequestReminders_ReturnsNonEmptyResult()
        Using context = New AocFlowEntities()
            Dim requestRepo As RequestRepository = New RequestRepository(New CommonRepository, New InstructionRepository)
            Dim result = requestRepo.GetRequestReminders()

            Assert.IsNotNull(result)
        End Using
    End Sub

    Private Function CreateReminderRequest(context As AocFlowEntities,
                                           reminderTermTypeId As Integer,
                                           reminderTerm As Integer,
                                           sentAt As Date) As Request

        Dim request As New Request()

        Dim userId = context.ApplicationUsers.First().Id
        Dim processTypeId = context.ProcessTypes.First().Id
        Dim template = MockHelper.CreateTemplate(userId, processTypeId)

        With template
            .ReminderTermTypeId = reminderTermTypeId
            .ReminderTerm = reminderTerm
        End With

        context.InstructionTemplates.Add(template)
        context.SaveChanges()

        Dim bankId = context.Banks.First().Id
        Dim teamId = context.Teams.First().Id
        Dim instruction = MockHelper.CreateInstruction(bankId, userId, template.Id, processTypeId, teamId)

        context.Instructions.Add(instruction)
        context.SaveChanges()

        request = MockHelper.CreateRequest(instruction.Id, userId)
        With request
            .SentAt = sentAt
        End With
        context.Requests.Add(request)
        context.SaveChanges()

        Return request
    End Function

    Private Function SetDefaultReminderTerm(context As AocFlowEntities, reminderTerm As Integer)

        Dim defaultReminderTermSetting = context.ApplicationSettings.FirstOrDefault(Function(x) x.Id = Setting.DefaultReminderTerm)
        If defaultReminderTermSetting IsNot Nothing Then
            If defaultReminderTermSetting.Value <> CStr(reminderTerm) Then
                defaultReminderTermSetting.Value = CStr(reminderTerm)
                context.ApplicationSettings.Attach(defaultReminderTermSetting)
                context.Entry(defaultReminderTermSetting).State = EntityState.Modified
                context.SaveChanges()
            End If
        Else
            defaultReminderTermSetting = MockHelper.SetDefaultReminderTerm(reminderTerm)
            context.ApplicationSettings.Add(defaultReminderTermSetting)
            context.SaveChanges()
        End If

        Return defaultReminderTermSetting

    End Function

    Private Function CreateMocks() As RequestRepositoryMocks
        Return New RequestRepositoryMocks() With {.RequestRepository = New RequestRepository(New CommonRepository(), New InstructionRepository())}
    End Function

    Public Class RequestRepositoryMocks
        Public Property RequestRepository As RequestRepository

    End Class

End Class