// Globalization (ISO) Setup clientside
//
// Javascript variables 'jsCulture' and 'jsDecimalSeparator' are rendered in the layout page

$(document).ready(function () {
    initGlobalization();
});


// Call this from the ready event
function initGlobalization()
{
    $.preferCulture(jsCulture);

    // Validate while typing if correct decimal number (on users culture)
    $('.decimalnumber').keydown(function (e) {

        // Allow: backspace, delete, tab, escape, enter, comma, dot and minus sign.
        if ($.inArray(e.keyCode, [46, 44, 8, 9, 27, 13, 110, 188, 190, 189]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }

        //// Values of textbox
        //var curValue = $(this).val();
        //var decimalsep = ($.format(0.1, 'n', jsCulture))[1]; // ',' or '.'
        //var thousandsep = (decimalsep == ',') ? '.' : ',';
     
        //// Max. 2 decimal digits
        //var decimalsepIndex = curValue.lastIndexOf(decimalsep);
        //if ((decimalsepIndex != -1) && (curValue.length > (decimalsepIndex + 2)))
        //{
        //    e.preventDefault();
        //}

    });

    // Validate while typing if correct whole number (on users culture)
    $('.wholenumber').keydown(function (e) {

        // Allow: backspace, delete, tab, escape, enter, comma, dot and minus sign.
        if ($.inArray(e.keyCode, [46, 44, 8, 9, 27, 13, 110, 189]) !== -1 ||
            // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

    if ($.validator) {

        // Override js validation method for (decimal) number
        $.validator.methods.number = function (value, element) {
            return this.optional(element) || isValidDecimalNumber(value, jsCulture);
        }

        // Override js validation method for number (range)
        $.validator.methods.range = function (value, element, param) {
            return this.optional(element) || ($.parseFloat(value, null, jsCulture) >= param[0] && $.parseFloat(value, null, jsCulture) <= param[1]);
        }

        $.validator.methods.date = function (value, element) {
            return this.optional(element) || $.parseDate(value, null, jsCulture);
        }


        // Fix the range to use globalized methods
        jQuery.extend(jQuery.validator.methods, {
            range: function (value, element, param) {
                //Use the Globalization plugin to parse the value
                var val = $.parseFloat(value, null, jsCulture);
                return this.optional(element) || (val >= param[0] && val <= param[1]);
            }
        });
    }
    //Setup datepickers if we don't support it natively!
    if (!Modernizr.inputtypes.date) {
        if (jsCulture != 'en-us' && jsCulture != 'en') {
            $.datepicker.setDefaults($.datepicker.regional[jsCulture]);
            $('.datepicker').datepicker();
        }
        $("input[type='datetime']").datepicker();
    }

}

// Check if decimal number is valid depending on the culture (e.g. 'nl-NL' or 'en-US')
function isValidDecimalNumber(sValue, jsCulture) {
    var theValue = $.parseFloat(sValue, null, jsCulture);
    var decimalsep = ($.format(0.1, 'n', jsCulture))[1]; // ',' or '.'
    var isInvalidDecNumberSep = (((decimalsep == ',') && (sValue.indexOf(",") == -1) && (sValue.indexOf('.') != -1)) || ((decimalsep == '.') && (sValue.indexOf(".") == -1) && (sValue.indexOf(',') != -1)));
    var isValueNumber = $.isNumeric(theValue); // this check only is not enough, since it can be a whole number ignoring the decimal sign when wrong separator was input

    var result = ((isValueNumber) && (!isInvalidDecNumberSep));
    return result;
}
